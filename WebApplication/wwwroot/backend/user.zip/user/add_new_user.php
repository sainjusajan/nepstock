<?php include ('header.php') ?>
<!--main content start-->
<section id="main-content">
  <section class="wrapper site-min-height">
    <!-- page start-->
    <section class="bread_crumb">
      <div class="row">
        <div class="col-md-6 col-sm-6">
          <h3>Add New User
          </h3>
          </div> <!-- // col -->
          <div class="col-md-6 col-sm-6">
            <ul class="crumbs">
              <li><a href="index.php">Home</a></li>
              <li> > </li>
              <li>My Users</li>
              <li> > </li>
              <li>Add New User</li>
            </ul>
            </div> <!-- // col -->
            </div> <!-- // row -->
            </section> <!-- // bread_crumb -->
            <div class="panel">
              <div class="panel-body">
                <form>
                <div class="row">
                <div class="col-md-6 col-sm-6">
  <div class="form-group">
    <label for="fname">First Name</label>
    <input type="text" class="form-control" id="fname" placeholder="First Name">
  </div>
                </div> <!-- // col -->
                  <div class="col-md-6 col-sm-6">
  <div class="form-group">
    <label for="lname">Last Name</label>
    <input type="text" class="form-control" id="lname" placeholder="Last Name">
  </div>
                </div> <!-- // col -->
                       <div class="col-md-6 col-sm-6">
  <div class="form-group">
    <label for="email">Email Address</label>
    <input type="email" class="form-control" id="email" placeholder="Email">
  </div>
                </div> <!-- // col -->
                  <div class="col-md-6 col-sm-6">
  <div class="form-group">
    <label for="mobile">Mobile</label>
    <input type="number" class="form-control" id="mobile" placeholder="mobile">
  </div>
                </div> <!-- // col -->
                        </div> <!-- // row -->
                              <button class="btn btn-success" type="submit"><i class="fa fa-paper-plane-o m-r-5"></i>Submit</button>
                              <a href="my_users.php" class="btn btn-warning"><i class="fa fa-arrow-left m-r-5"></i>Go Back</a>

                      </form>
                        </div> <!-- //panel-body -->
                        </div> <!-- // panel -->
                        <!-- page end-->
                      </section>
                      <!-- //wrapper -->
                    </section>
                    <!--main content end-->
                    <?php include ('footer.php') ?>